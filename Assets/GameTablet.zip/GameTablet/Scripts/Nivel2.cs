﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nivel2 :Niveles
{

    public override void configuration()
    {
        
    }
    public override void spawn()
    {

        
    }
    public override void valorAdivinar()
    {

    }

}

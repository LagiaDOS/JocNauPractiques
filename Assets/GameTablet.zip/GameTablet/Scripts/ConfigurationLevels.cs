﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ConfigurationLevels {
    
    void configuration();
    void spawn();

    void init();
}

